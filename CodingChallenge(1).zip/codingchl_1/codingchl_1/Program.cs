﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codingchl_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Private Variabel
            int jml_uang, besar_uang, tukar;
            double komisi, lembaran;

            //User Input
            Console.Write("Berapa uang yang akan ditukar: "); besar_uang = Convert.ToInt32(Console.ReadLine()); //besar_uang = 1000, kalu misal(inputnya 1000)
            Console.Write("Berapa jumlah uang yang ingin ditukar: "); jml_uang = Convert.ToInt32(Console.ReadLine()); //..
            Console.Write("Berapa pecahan yang ingin anda diterima: "); tukar = Convert.ToInt32(Console.ReadLine()); //.

            //Garis Baru
            Console.WriteLine();

            //Variabel sementara
            int tampung;

            //Rumus (Perhitungan)
            tampung = besar_uang * jml_uang; //Sekarang variabel tampung = 1000 * 2;
            komisi = tampung * 0.1; //Sekarang variabel komisi = 2000 * 0.1;
            lembaran = (tampung / tukar); //Sekarang variabel lembaran = 2000 * 100;

            //Output Hasil
            Console.WriteLine("Komisi saya: " +komisi); //Tampilin hasil komisi
            Console.WriteLine("Jumlah lembar kecil yang diterima oleh pelanggan: " + lembaran); //Tampilin hasil lembaran
            Console.ReadLine(); //Baca baris
        }
    }
}
